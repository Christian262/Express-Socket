const express = require("express");
const app = express();
const path = require("path");
const bodyParser = require("body-parser");
const port = process.env.PORT || 8000;

app.use(bodyParser.urlencoded({ extended: true}));

app.use(express.static(path.join(__dirname, "./static")));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

const server = app.listen(8000, () =>
    console.log("Listen on port 8000"));

const io = require('socket.io').listen(server);

var count = 0;

app.get('/', function(req, res) {
    res.render("index");
});

io.sockets.on('connection', function(socket){
    console.log(count);

    socket.on('epic', function () {
        update(++count);
    });

    socket.on('reset', function(){
        update(count = 0);
    });
    function update(count){
        io.sockets.emit('update', count);
    }
});
